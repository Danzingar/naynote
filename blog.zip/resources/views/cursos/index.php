<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=7, initial-scale=1.0">
    <title>Pinche index</title>
</head>
<body>
    <h1>estas en el pinche index we no manches</h1>
</body>
</html>
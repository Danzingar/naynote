<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=7, initial-scale=1.0">
    <title>Create algo</title>
</head>
<body>
    <h1>ponte a crear algo huevon</h1>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=7, initial-scale=1.0">
    <title><?php echo $curso?></title>
</head>
<body>
    <h1>estas en show bato <?php echo $curso?></h1>
</body>
</html>
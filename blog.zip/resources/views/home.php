<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=7, initial-scale=1.0">
    <title>Inicio</title>
</head>
<body>
    <h1>Estas en la pagina home :P</h1>
</body>
</html>